<!--
title: Knative - Knative - CLI Reference
menuText: CLI Reference
layout: Doc
-->

<!-- DOCS-SITE-LINK:START automatically generated  -->

### [Read this on the main serverless docs site](https://www.serverless.com/framework/docs/providers/knative/cli-reference/)

<!-- DOCS-SITE-LINK:END -->

# Serverless CLI Reference for Knative

Welcome to the Serverless CLI Reference for Knative. Please select a section on the left to get started.
