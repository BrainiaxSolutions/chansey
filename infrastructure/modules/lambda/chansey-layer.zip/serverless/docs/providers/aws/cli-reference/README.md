<!--
title: Serverless - AWS Lambda - CLI Reference
menuText: CLI Reference
layout: Doc
-->

<!-- DOCS-SITE-LINK:START automatically generated  -->

### [Read this on the main serverless docs site](https://www.serverless.com/framework/docs/providers/aws/cli-reference/)

<!-- DOCS-SITE-LINK:END -->

# Serverless CLI Reference for AWS

Welcome to the Serverless CLI Reference for AWS. Please select a section on the left to get started.

If you have questions, join the [Slack community](https://serverless.com/slack) or [post over on the forums](https://forum.serverless.com/)
