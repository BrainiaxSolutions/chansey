<!--
title: Serverless - Fn - Events
menuText: Fn Events
layout: Doc
-->

<!-- DOCS-SITE-LINK:START automatically generated  -->

### [Read this on the main serverless docs site](https://www.serverless.com/framework/docs/providers/fn/events/)

<!-- DOCS-SITE-LINK:END -->

# Serverless Fn Events

Welcome to the Serverless Fn Events Glossary!

Please select a section on the left to get started.

If you have questions, join the [Slack community](https://serverless.com/slack) or [post over on the forums](http://forum.serverless.com/)
